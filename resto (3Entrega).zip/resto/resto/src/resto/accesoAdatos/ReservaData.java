
package resto.accesoAdatos;

import java.sql.Connection;
import resto.entidades.Reserva;
import java.sql.PreparedStatement;
import java.sql.Statement;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.sql.Time;



public class ReservaData {
       private Connection con=null;//atributo Connection (lo utilizarán todas las clases Data para poder guardar/eliminar/consultar datos de la base de datos

    public ReservaData() {//Constructor para inicializar la variable atributo Connection
        con=ConexionBD.getConexion();//se encargara de cargar los driver y establecer la conexion a la base de datos SI ES QUE NO SE HIZO ANTES
    }
//Métodos------------------------------------------------------------------------------------------------------------------------------
    public void agregarReserva(Reserva reserva , int idMesa){//este metodo tendrá la tarea de hacer in INSERT en la tabla reserva
       String sql = "INSERT INTO reserva(nombre, dni, fecha, hora , estado,idMesa)" + " VALUES (?,?,?,?,?,?)";
           try {
               //generamos el objeto PreparedStatement----
               PreparedStatement pre = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
               pre.setString(1, reserva.getNombre());
               pre.setDouble(2, reserva.getDni());
               pre.setDate(3, Date.valueOf (reserva.getFecha()));//LocalDate fecha;se debe tranformar a date, se invoca el metodo value of y le pasamos x parametro reserva.get fecha
               pre.setTime(4, Time.valueOf(reserva.getHora()));//LocalTime hora;
               pre.setBoolean(5, reserva.isEstado());
               pre.setInt(6,idMesa );
               pre.executeUpdate();
           
               //ahora devolvera lista con claves generadas a mesa 
            ResultSet res = pre.getGeneratedKeys(); //guardamos elr esultado de la variable pre en un RESULTSET
            //RESULSET=matriz/tabla con una sola columna que seria el id y filas tantas como mesas haya insertado 
            if (res.next()) {//recorremos el resulset con un if
                reserva.setIdReserva(1);
                JOptionPane.showMessageDialog(null, "Reserva Agregada");
            }
            pre.close();//cerramos el preparedstatement
               
           } catch (SQLException ex) {
               JOptionPane.showMessageDialog(null, "Error al acceder a la TABLA RESERVA"+ex.getMessage());
           }
            
    }
//----------------------------------------------------------------------------------------------------------------------------------------------
    public void eliminarReserva(Reserva reserva){
       String sql="UPDATE reserva SET estado=0 WHERE idReserva=?";
           try {
               PreparedStatement pre=con.prepareStatement(sql);
               pre.setBoolean(1, reserva.isEstado());
                 int exe=pre.executeUpdate();//executeUpdate devuelve un entero y lo almacenamos en una variable
            if(exe==1) {
                JOptionPane.showMessageDialog(null, "Reserva Eliminada");
            }
           } catch (SQLException ex) {
               JOptionPane.showMessageDialog(null, "Error al acceder a la tabla RESERVA para eliminar ");
           }
    }
//----------------------------------------------------------------------------------------------------------------------------------------------
   public void modificarReserva(Reserva reserva){
       String sql="UPDATE reserva SET nombre=? WHERE idReserva=?";
           try {
               PreparedStatement pre=con.prepareStatement(sql);
               pre.setString(1, reserva.getNombre());
               pre.setInt(2, reserva.getIdReserva());
               
                int exe=pre.executeUpdate();//executeUpdate devuelve un entero y lo almacenamos en una variable
            if(exe==1){
                JOptionPane.showMessageDialog(null, "Reserva Modificada!");
            }
            pre.close();
           } catch (SQLException ex) {
               JOptionPane.showMessageDialog(null,"Error al acceder a la Tabla Reserva para modificar"+ex.getMessage());
           }
   }  
//----------------------------------------------------------------------------------------------------------------------------------------------  
     public Reserva buscarReserva(int id){
        String sql="SELECT nombre, dni , fecha, hora FROM reserva WHERE idReserva=? AND estado=1";
        Reserva reserva=null;
        try {
            PreparedStatement pre=con.prepareStatement(sql);
            pre.setInt(1, id);
            ResultSet re=pre.executeQuery();
            if(re.next()){
                reserva=new Reserva();
                reserva.setIdReserva(id);
                reserva.setNombre(re.getString("nombre"));
                reserva.setDni(re.getInt("dni"));
                reserva.setFecha(re.getDate("fecha").toLocalDate());
                reserva.setHora(re.getTime("hora").toLocalTime());
                reserva.setEstado(true);
                
            }else{
                
                JOptionPane.showMessageDialog(null, "No existe el Producto");
            }
            pre.close();
            
        } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null, "Error al acceder a la tabla Mesa para buscar mesa"+ex.getMessage());
        }
        return reserva;
    }
//---------------------------------------------------------------------------------------------------------------------------------------------- 
}
