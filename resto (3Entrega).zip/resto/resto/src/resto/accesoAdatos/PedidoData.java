
package resto.accesoAdatos;

import java.sql.Connection;


public class PedidoData {
       private Connection con=null;//atributo Connection (lo utilizarán todas las clases Data para poder guardar/eliminar/consultar datos de la base de datos

    public PedidoData() {//Constructor para inicializar la variable atributo Connection
        con=ConexionBD.getConexion();//se encargara de cargar los driver y establecer la conexion a la base de datos SI ES QUE NO SE HIZO ANTES
    }
    
}
