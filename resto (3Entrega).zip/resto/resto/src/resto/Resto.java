package resto;

import java.sql.Connection;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Month;
import resto.accesoAdatos.ConexionBD;
import resto.accesoAdatos.MesaData;
import resto.accesoAdatos.MeseroData;
import resto.accesoAdatos.ProductoData;
import resto.accesoAdatos.ReservaData;
import resto.entidades.Mesa;
import resto.entidades.Mesero;
import resto.entidades.Producto;
import resto.entidades.Reserva;

public class Resto {

    public static void main(String[] args) {

        // guardamos en una variable de tipo connection lo que me devolvera  el metodo GETCONEXION 
        Connection con = ConexionBD.getConexion();//llamamos al metodo desde su clase 

        //crearé una mesa
        Mesa mesaonce=new Mesa(11,10,true);//alumno guardado en la memoria
        MesaData mess=new MesaData();//alumno guardadod en la base de datos
//        mess.agregarMesa(mesaonce);//llamamos al metodo para agregar mesa
        //---------------------------------------------------------------------
        Mesa mesauno=new Mesa(3,1,8,true);
        
//        Mesa mesados=new Mesa(2,2,true);
//        Mesa mesatres=new Mesa(3,6,true);
//        Mesa mesacuatro=new Mesa(4,4,true);
//        Mesa mesacinco=new Mesa(5,8,true);
//        Mesa mesaseis=new Mesa(6,6,true);
//        Mesa mesasiet=new Mesa(7,6,true);
//        Mesa mesaoch=new Mesa(8,8,true);
//        Mesa mesanuev=new Mesa(9,9,true);
//        mess.agregarMesa(mesauno);
//        mess.agregarMesa(mesados);
//        mess.agregarMesa(mesatres);
//        mess.agregarMesa(mesacuatro);
//        mess.agregarMesa(mesacinco);
//        mess.agregarMesa(mesaseis);
//        mess.agregarMesa(mesasiet);
//        mess.agregarMesa(mesaoch);
//        mess.agregarMesa(mesanuev);
//Eliminar----------
//          mess.borrarMesa(mesauno);
//Modificar---------
//          mess.modificarMesa(mesauno);
//Buscar------------
//            Mesa mesaEncontrada=mess.buscarMesa(10);//almaceno en un variable el valor que me devolvera el metodo
//            System.out.println("Mesa encontrada con el ID ingresado "+mesaEncontrada);
            
//--------------------------------------------------------------------------------------------------------------------------------------------------
        //crearé un mesero
        Mesero juanito=new Mesero(1,"Juan Pablillo",40444444,"juanPablo@gmail.com","juanPablo1234",true);
        MeseroData meser=new MeseroData();
//        meser.AgregarMesero(juanito);
        //---------------------------------------------------------------------
//        Mesero felipe=new Mesero("Felipe",45500500,"Felipe@gmail.com","Feli2024",true);
//        Mesero Rita=new Mesero("Rita",49930900,"Rita00@gmail.com","Rresto024",true);
//        Mesero Luana=new Mesero("Luana",38830300,"Luana20qgmail.com","L20ñ.",true);
//        meser.AgregarMesero(felipe);
//        meser.AgregarMesero(Rita);
//        meser.AgregarMesero(juanito);
//Eliminar----------
//        meser.borrarMesero(juanito);
//Modificar---------
//        meser.modificarMesero(juanito);
//Buscar-------------
//          Mesero meseroEncontrado=meser.buscarMesero(4);
//          System.out.println("Mesero Encontrado con el ID inresado"+meseroEncontrado);
//--------------------------------------------------------------------------------------------------------------------------------------------------
        //crearé un producto
        Producto pizza=new Producto(17,070,"Pizza Especial ",5,6800,true);
        ProductoData produc=new ProductoData();
//        produc.agregarProducto(pizza);
// ---------------------------------------------------------------------
//          Producto hambur=new Producto(507,"Hamburguesa(confritas)",6,7000,true);
//          Producto hamburg=new Producto(504,"Hamburgueza Grande (com fritas)",4,7800,true);
          Producto lomo=new Producto(21,300,"Lomo",8,8000,true);
//          Producto pastas=new Producto(022,"Tallarines con Tuco",10,3000,true);
//          Producto empan=new Producto(012,"Empanadas JyQ(1 docena)",14,8000,true);
//          Producto empanC=new Producto(011,"Empanas de Carne (1 docena)",15,7000,true);
//          Producto lomopizza=new Producto(001,"LomoPizza (con fritas)",4,16000,true);
//          Producto hamburpizz=new Producto(002,"Harburpizza",6,12000,true);
//          Producto pollo=new Producto(010,"Pollo Asado",12,13500,true);
//          Producto frit=new Producto(0012,"Fritas Grandes XL",8,5000,true);
//          Producto fritas=new Producto(011,"Fritas Chicas",8,3500,true);
//          produc.agregarProducto(hambur);
//          produc.agregarProducto(hamburg);
//          produc.agregarProducto(lomo);
//          produc.agregarProducto(pastas);
//          produc.agregarProducto(empan);
//          produc.agregarProducto(empanC);
//          produc.agregarProducto(lomopizza);
//          produc.agregarProducto(hamburpizz);
//          produc.agregarProducto(pollo);
//          produc.agregarProducto(frit);
//          produc.agregarProducto(fritas);
//Eliminar--------
//          produc.borrarProducto(hambur);
//Modificar--------
//          produc.modificarProducto(lomo);
//Buscar------------
//          Producto productoEncontrado= produc.buscarProducto(20);
//          System.out.println("Producto Encontrado con el ID ingresado"+productoEncontrado);
//Listar------------
//            ProductoData pro=new ProductoData();
//            for(Producto producto:pro.listarProducto()){
//                System.out.print(producto.getNombre()+" ");
//                System.out.print("$"+producto.getPrecio());
//                System.out.print(" Cantidad: " +producto.getCantidad());
//                System.out.println(" - ");
//            }
          
            
            
//--------------------------------------------------------------------------------------------------------------------------------------------------
        //crearé una reserva
       
        Reserva re=new Reserva("Luisana",29305590,LocalDate.of(2024, 10, 20),LocalTime.of(21, 00),true);
        ReservaData reserva=new ReservaData();
//Agregar----------
//        reserva.agregarReserva(re,2);
        Reserva res=new Reserva(2,"José Luis Antonio",23172481,LocalDate.of(2024, Month.DECEMBER, 24),LocalTime.of(22, 00),true);
//        reserva.agregarReserva(res, 10);
//Eliminar---------
//        reserva.eliminarReserva(res);
//Modificar--------
//        reserva.modificarReserva(res);
//Buscar-----------
//         Reserva reservaEncontrada= reserva.buscarReserva(2);
//         System.out.println("Reserva encontrada con el ID ingresado:"+reservaEncontrada);
//--------------------------------------------------------------------------------------------------------------------------------------------------
                
   }

}
