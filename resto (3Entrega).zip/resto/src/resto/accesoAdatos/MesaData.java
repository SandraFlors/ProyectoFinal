
package resto.accesoAdatos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import resto.entidades.Mesa;

public class MesaData {

    private Connection con = null;//atributo Connection (lo utilizarán todas las clases Data para poder guardar/eliminar/consultar datos de la base de datos

    public MesaData() {//Constructor para inicializar la variable atributo Connection
        con = ConexionBD.getConexion();//se encargara de cargar los driver y establecer la conexion a la base de datos SI ES QUE NO SE HIZO ANTES
    }
//Métodos------------------------------------------------------------------------------------------------------------------------------
    public void agregarMesa(Mesa mesa) { //este metodo tendrá la tarea de hacer in INSERT en la tabla Mesa
        String sql = "INSERT INTO mesa(numero, capacidad, estado)" + " VALUES (?,?,?)"; //datos a cargar (caracter comodin) luego remplazamos los signos por los datos correspondientes
        try {
            //generamos el objeto PreparedStatement----
            PreparedStatement pre = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            pre.setInt(1, mesa.getNumero()); //SET=método de preparedStatement (1 UN metodo set x cada tipo de dato)
            pre.setInt(2, mesa.getCapacidad());
            pre.setBoolean(3, mesa.isEstado());//estado booleano - IS remplazaria el metodo get del estado
            pre.executeUpdate();

            //ahora devolvera lista con claves generadas a mesa 
            ResultSet re = pre.getGeneratedKeys(); //guardamos elr esultado de la variable pre en un RESULTSET
            //RESULSET=matriz/tabla con una sola columna que seria el id y filas tantas como mesas haya insertado 
            if (re.next()) {//recorremos el resulset con un if
                mesa.setIdMesa(re.getInt(1));
                JOptionPane.showMessageDialog(null, "Mesa Agregada");
            }
            pre.close();//cerramos el preparedstatement
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Eror al acceder a la TABLA MESA" + ex.getMessage());
        }
    }
//----------------------------------------------------------------------------------------------------------------------------------------------
    public void borrarMesa(Mesa mesa){//este metodo se encargará de eliminar una mesa (DELETE)
        String sql="UPDATE mesa SET estado=0 WHERE idMesa=?";
        try {
            PreparedStatement pre=con.prepareStatement(sql);
            pre.setBoolean(1, mesa.isEstado());//seteamos el parametro
            int exe=pre.executeUpdate();//executeUpdate devuelve un entero y lo almacenamos en una variable
            if(exe==1) {
                JOptionPane.showMessageDialog(null, "Mesa Eliminada");
            }
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a la tabla para Eliminar Mesa"+ex.getMessage());
        }
        
    }
//----------------------------------------------------------------------------------------------------------------------------------------------    
    public void modificarMesa(Mesa mesa){//este metodo se encargará de hacer una modificacion en la tabla(UPDATE)
        String sql="UPDATE mesa SET numero=?, capacidad=? WHERE IdMesa=?";
        try {
            PreparedStatement pre=con.prepareStatement(sql);
            pre.setInt(1, mesa.getNumero());//seteamos los parametros
            pre.setInt(2, mesa.getCapacidad());
            pre.setInt(3, mesa.getIdMesa());
            int exe=pre.executeUpdate();//executeUpdate devuelve un entero y lo almacenamos en una variable
            if(exe==1){
                JOptionPane.showMessageDialog(null, "Mesa Modificada!");
            }
            pre.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a la tabla para Modificar mesa"+ex.getMessage());
        }  
    }
//----------------------------------------------------------------------------------------------------------------------------------------------  
    public Mesa buscarMesa(int id){
        String sql="SELECT numero, capacidad FROM mesa WHERE idMesa=? AND estado=1";
        Mesa mesa=null;
        try {
            PreparedStatement pre=con.prepareStatement(sql);
            pre.setInt(1, id);
            ResultSet re=pre.executeQuery();
            if(re.next()){
                mesa=new Mesa();
                mesa.setIdMesa(id);
                mesa.setNumero(re.getInt("numero"));
                mesa.setCapacidad(re.getInt("capacidad"));
                mesa.setEstado(true);
                
            }else{
                
                JOptionPane.showMessageDialog(null, "No existe la mesa");
            }
            pre.close();
            
        } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null, "Error al acceder a la tabla Mesa para buscar mesa"+ex.getMessage());
        }
        return mesa;
    }
//----------------------------------------------------------------------------------------------------------------------------------------------   
    public List<Mesa> listarMesas(){
        ArrayList<Mesa> mesas=new ArrayList<>();
        String sql="SELECT * FROM mesa";
        try{
            PreparedStatement pre=con.prepareStatement(sql);
            ResultSet re=pre.executeQuery();//devuelve un resultset
            while(re.next()){
                Mesa mesa=new Mesa();
                mesa.setIdMesa(re.getInt("idMesa"));
                mesa.setNumero(re.getInt("numero"));
                mesa.setCapacidad(re.getInt("capacidad"));
                mesa.setEstado(re.getBoolean("estado"));
                mesas.add(mesa);
            }
            pre.close();
            
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Error al acceder a la tabla Mesa");
        }
       return mesas; 
    }
//----------------------------------------------------------------------------------------------------------------------------------------------  
    
    
    
    
}






