
package resto.accesoAdatos;

import java.sql.Connection;
import resto.entidades.Pedido;
import java.sql.PreparedStatement;
import java.sql.Statement;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PedidoData {
       private Connection con=null;//atributo Connection (lo utilizarán todas las clases Data para poder guardar/eliminar/consultar datos de la base de datos

    public PedidoData() {//Constructor para inicializar la variable atributo Connection
        con=ConexionBD.getConexion();//se encargara de cargar los driver y establecer la conexion a la base de datos SI ES QUE NO SE HIZO ANTES
    }
    
    //Métodos------------------------------------------------------------------------------------------------------------------------------
    public void AgregarPedido(Pedido pedido){//este metodo tendrá la tarea de hacer in INSERT en la tabla peedido
        String sql="INSERT INTO pedido(estado,idMesa,idMesero,idProducto)"+" VALUES (?,?,?,?)";//datos a cargar (caracter comodin) luego remplazamos los signos por los datos correspondientes
           try {
               //generamos el objeto PreparedStatement----
               PreparedStatement pre=con.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
               //SET=método de preparedStatement (1 UN metodo set x cada tipo de dato)
             pre.setBoolean(1, pedido.isEstado());
               pre.setInt(2,pedido.getMesa().getIdMesa());
               pre.setInt(3, pedido.getMesero().getIdMesero());
               pre.setInt(4, pedido.getProducto().getIdProducto());
               
               pre.executeUpdate();
               
                  //get generated keys )ahora devolvera lista con claves generadas a mesero
            ResultSet re = pre.getGeneratedKeys(); //guardamos el resultado de la variable pre en un RESULTSET
            //RESULSET=matriz/tabla con una sola columna que seria el id y filas tantas como mesas haya insertado (en nuestro caso solo 1 )
            if (re.next()) {//recorremos el resulset con un if
                pedido.setIdPedido(re.getInt(1));
                JOptionPane.showMessageDialog(null, "Pedido Agregado");
            }
            pre.close();//cerramos el preparedstatement
            
           } catch (SQLException ex) {
               JOptionPane.showMessageDialog(null, "Error al acceder a la TABLA PEDIDO"+ex.getMessage());
           }
    }
  //Métodos------------------------------------------------------------------------------------------------------------------------------    
     
}
