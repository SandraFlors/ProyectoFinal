
package resto.vistas;

import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;

public class Ventana extends javax.swing.JFrame {

   
    public Ventana() {
        initComponents();
    }

 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jMenuItem6 = new javax.swing.JMenuItem();
        ImageIcon icono=new ImageIcon(getClass().getResource("/resto/icons/fuegoazul.jpg"));
        Image miImagen=icono.getImage();
        Escritorio = new javax.swing.JDesktopPane(){
            public void paintComponent(Graphics g){
                g.drawImage(miImagen,0,0,getWidth(),getHeight(),this);
            }
        };
        lbltelefono = new javax.swing.JLabel();
        lblhubicacion = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        menuMeseros = new javax.swing.JMenu();
        itemMeseros = new javax.swing.JMenuItem();
        menuMesa = new javax.swing.JMenu();
        itemClientes = new javax.swing.JMenuItem();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        menuSalir = new javax.swing.JMenu();

        jButton1.setText("jButton1");

        jMenuItem6.setText("jMenuItem6");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Resto Delicatessen");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Escritorio.setToolTipText("");
        Escritorio.setPreferredSize(new java.awt.Dimension(500, 550));

        lbltelefono.setBackground(new java.awt.Color(0, 0, 0));
        lbltelefono.setFont(new java.awt.Font("Dialog", 3, 18)); // NOI18N
        lbltelefono.setForeground(new java.awt.Color(255, 255, 255));
        lbltelefono.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resto/icons/call.png"))); // NOI18N
        lbltelefono.setText("2664703074");

        lblhubicacion.setBackground(new java.awt.Color(0, 0, 0));
        lblhubicacion.setFont(new java.awt.Font("Dialog", 3, 18)); // NOI18N
        lblhubicacion.setForeground(new java.awt.Color(255, 255, 255));
        lblhubicacion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resto/icons/location (1).png"))); // NOI18N
        lblhubicacion.setText("San Luis Capital");

        jLabel3.setBackground(new java.awt.Color(0, 0, 0));
        jLabel3.setFont(new java.awt.Font("Book Antiqua", 1, 50)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Delicatessen");

        Escritorio.setLayer(lbltelefono, javax.swing.JLayeredPane.DEFAULT_LAYER);
        Escritorio.setLayer(lblhubicacion, javax.swing.JLayeredPane.DEFAULT_LAYER);
        Escritorio.setLayer(jLabel3, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout EscritorioLayout = new javax.swing.GroupLayout(Escritorio);
        Escritorio.setLayout(EscritorioLayout);
        EscritorioLayout.setHorizontalGroup(
            EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EscritorioLayout.createSequentialGroup()
                .addGap(0, 102, Short.MAX_VALUE)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 302, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(86, 86, 86))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, EscritorioLayout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(lblhubicacion, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lbltelefono)
                .addGap(40, 40, 40))
        );
        EscritorioLayout.setVerticalGroup(
            EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, EscritorioLayout.createSequentialGroup()
                .addContainerGap(150, Short.MAX_VALUE)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(74, 74, 74)
                .addGroup(EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbltelefono)
                    .addComponent(lblhubicacion))
                .addGap(187, 187, 187))
        );

        getContentPane().add(Escritorio, new org.netbeans.lib.awtextra.AbsoluteConstraints(4, 4, 490, 530));

        menuMeseros.setBackground(new java.awt.Color(255, 255, 255));
        menuMeseros.setForeground(new java.awt.Color(0, 0, 0));
        menuMeseros.setText("Meseros");
        menuMeseros.setFont(new java.awt.Font("Book Antiqua", 1, 12)); // NOI18N

        itemMeseros.setBackground(new java.awt.Color(255, 255, 255));
        itemMeseros.setFont(new java.awt.Font("Book Antiqua", 1, 12)); // NOI18N
        itemMeseros.setForeground(new java.awt.Color(0, 0, 0));
        itemMeseros.setText("Formulario Meseros");
        itemMeseros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemMeserosActionPerformed(evt);
            }
        });
        menuMeseros.add(itemMeseros);

        jMenuBar1.add(menuMeseros);

        menuMesa.setBackground(new java.awt.Color(255, 255, 255));
        menuMesa.setForeground(new java.awt.Color(0, 0, 0));
        menuMesa.setText("Producto y Pedidos");
        menuMesa.setFont(new java.awt.Font("Book Antiqua", 1, 12)); // NOI18N

        itemClientes.setBackground(new java.awt.Color(255, 255, 255));
        itemClientes.setFont(new java.awt.Font("Book Antiqua", 1, 12)); // NOI18N
        itemClientes.setForeground(new java.awt.Color(0, 0, 0));
        itemClientes.setText("Formulario Producto");
        itemClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemClientesActionPerformed(evt);
            }
        });
        menuMesa.add(itemClientes);

        jMenuBar1.add(menuMesa);

        jMenu1.setBackground(new java.awt.Color(255, 255, 255));
        jMenu1.setForeground(new java.awt.Color(0, 0, 0));
        jMenu1.setText("Reservas");
        jMenu1.setFont(new java.awt.Font("Book Antiqua", 1, 12)); // NOI18N

        jMenuItem1.setBackground(new java.awt.Color(255, 255, 255));
        jMenuItem1.setFont(new java.awt.Font("Book Antiqua", 1, 12)); // NOI18N
        jMenuItem1.setForeground(new java.awt.Color(0, 0, 0));
        jMenuItem1.setText("FormularioReservas");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuBar1.add(jMenu1);

        menuSalir.setBackground(new java.awt.Color(255, 255, 255));
        menuSalir.setForeground(new java.awt.Color(0, 0, 0));
        menuSalir.setText("Salir");
        menuSalir.setFont(new java.awt.Font("Book Antiqua", 1, 12)); // NOI18N
        menuSalir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuSalirMouseClicked(evt);
            }
        });
        menuSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuSalirActionPerformed(evt);
            }
        });
        jMenuBar1.add(menuSalir);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void itemMeserosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemMeserosActionPerformed
        // TODO add your handling code here:
        IngresoMeseros mesero=new IngresoMeseros(); 
        Escritorio.add(mesero);
        mesero.setVisible(true);
    }//GEN-LAST:event_itemMeserosActionPerformed

    private void itemClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemClientesActionPerformed
 
        ingresoClientes cliente=new ingresoClientes();
        Escritorio.add(cliente);
        cliente.setVisible(true);
    }//GEN-LAST:event_itemClientesActionPerformed

    private void menuSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuSalirActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_menuSalirActionPerformed

    private void menuSalirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuSalirMouseClicked
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_menuSalirMouseClicked

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        // TODO add your handling code here:
        FormulariosReservas formula=new FormulariosReservas();
        Escritorio.add(formula);
        formula.setVisible(true);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

   
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Ventana().setVisible(true);
            }
        });
    }


 
public class MainClass {
    public static void main(String[] args) {
        // Configuración de la interfaz gráfica
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                // Crear y mostrar el JFrame
                new Ventana().setVisible(true);
                
            }
        });
    }
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JDesktopPane Escritorio;
    private javax.swing.JMenuItem itemClientes;
    private javax.swing.JMenuItem itemMeseros;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JLabel lblhubicacion;
    private javax.swing.JLabel lbltelefono;
    private javax.swing.JMenu menuMesa;
    private javax.swing.JMenu menuMeseros;
    private javax.swing.JMenu menuSalir;
    // End of variables declaration//GEN-END:variables
}
