
package resto.vistas;

import java.awt.Graphics;
import java.awt.Image;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import resto.accesoAdatos.MesaData;
import resto.accesoAdatos.MeseroData;
import resto.accesoAdatos.PedidoData;
import resto.accesoAdatos.ProductoData;
import resto.entidades.Mesa;
import resto.entidades.Mesero;
import resto.entidades.Pedido;
import resto.entidades.Producto;


public class ingresoClientes extends javax.swing.JInternalFrame {

    private ArrayList<Producto>listaP;
    private ArrayList<Mesa>listaM;
    private ArrayList<Mesero>listameser;
    
   private MesaData mesaData;
   private MeseroData meserData;
   private ProductoData proData;
   private PedidoData pedData;
   
   private DefaultTableModel modelo;
   
    public ingresoClientes() {
        initComponents();
        
        proData = new ProductoData();
        listaP = (ArrayList<Producto>)proData.listarProducto();
        mesaData=new MesaData();
        listaM=(ArrayList<Mesa>)mesaData.listarMesas();
        meserData=new MeseroData();
        listameser=(ArrayList<Mesero>)meserData.listarMeseros();
        pedData=new PedidoData();
        
        modelo=new DefaultTableModel();
        
        
        
        //metodos
        cargaMesa();
        
        armarCabezeraTabla();
        
        cargarDatosPedidos();
        
        cargaMeseros() ;
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        ImageIcon icono=new ImageIcon(getClass().getResource("/resto/icons/humo.jpg"));
        Image miImagen=icono.getImage();
        jPanel1 = new javax.swing.JPanel(){
            public void paintComponent(Graphics g){
                g.drawImage(miImagen,0,0,getWidth(),getHeight(),this);
            }
        };
        btnSalir = new javax.swing.JButton();
        lblselecMesa = new javax.swing.JLabel();
        lblselecMesero = new javax.swing.JLabel();
        lblselecProducto = new javax.swing.JLabel();
        btnAgregarPedido = new javax.swing.JButton();
        comboMesa = new javax.swing.JComboBox<>();
        comboMesero = new javax.swing.JComboBox<>();
        jScrollPane3 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        lblPedidos = new javax.swing.JLabel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        jLabel1.setText("jLabel1");

        jLabel2.setText("jLabel2");

        setTitle("Pedido");

        btnSalir.setBackground(new java.awt.Color(255, 255, 255));
        btnSalir.setFont(new java.awt.Font("Book Antiqua", 1, 12)); // NOI18N
        btnSalir.setForeground(new java.awt.Color(0, 0, 0));
        btnSalir.setText("Salir");
        btnSalir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnSalirMouseClicked(evt);
            }
        });

        lblselecMesa.setBackground(new java.awt.Color(0, 0, 0));
        lblselecMesa.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        lblselecMesa.setForeground(new java.awt.Color(255, 255, 255));
        lblselecMesa.setText("Seleccione Mesa : ");

        lblselecMesero.setBackground(new java.awt.Color(0, 0, 0));
        lblselecMesero.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        lblselecMesero.setForeground(new java.awt.Color(255, 255, 255));
        lblselecMesero.setText("Seleccione Mesero : ");

        lblselecProducto.setBackground(new java.awt.Color(0, 0, 0));
        lblselecProducto.setForeground(new java.awt.Color(255, 255, 255));
        lblselecProducto.setText("Seleccione Poducto :");

        btnAgregarPedido.setBackground(new java.awt.Color(255, 255, 255));
        btnAgregarPedido.setFont(new java.awt.Font("Book Antiqua", 1, 12)); // NOI18N
        btnAgregarPedido.setForeground(new java.awt.Color(0, 0, 0));
        btnAgregarPedido.setText("AgregarPedido");
        btnAgregarPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarPedidoActionPerformed(evt);
            }
        });

        comboMesa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboMesaActionPerformed(evt);
            }
        });

        comboMesero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboMeseroActionPerformed(evt);
            }
        });

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(tabla);

        lblPedidos.setFont(new java.awt.Font("Book Antiqua", 1, 24)); // NOI18N
        lblPedidos.setForeground(new java.awt.Color(255, 255, 255));
        lblPedidos.setText("Pedidos");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblselecMesa)
                        .addGap(18, 18, 18)
                        .addComponent(comboMesa, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblselecProducto)
                            .addComponent(lblselecMesero))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btnAgregarPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 114, Short.MAX_VALUE)
                                .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addComponent(comboMesero, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(138, 138, 138))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(191, 191, 191)
                .addComponent(lblPedidos)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(lblPedidos)
                .addGap(40, 40, 40)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboMesa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblselecMesa))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboMesero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblselecMesero))
                .addGap(76, 76, 76)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblselecProducto))
                .addGap(38, 38, 38)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAgregarPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(73, 73, 73))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSalirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSalirMouseClicked
        //BOTON SALIR
        dispose();
    }//GEN-LAST:event_btnSalirMouseClicked

    private void comboMesaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboMesaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboMesaActionPerformed

    private void comboMeseroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboMeseroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboMeseroActionPerformed

    private void btnAgregarPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarPedidoActionPerformed
        // BOTON AGREGAR PEDIDO
        Mesa m=(Mesa)comboMesa.getSelectedItem();
           Mesero me=(Mesero)comboMesero.getSelectedItem();
        
        
       if(m==null || me==null){
  JOptionPane.showMessageDialog(null, "Debe seleccionar una mesa y un mesero");
       }
        Pedido pedido=new Pedido();
        
        for(int i=0;i<tabla.getRowCount();i++){
            
        }
            
        
    }//GEN-LAST:event_btnAgregarPedidoActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregarPedido;
    private javax.swing.JButton btnSalir;
    private javax.swing.JComboBox<Mesa> comboMesa;
    private javax.swing.JComboBox<Mesero> comboMesero;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JLabel lblPedidos;
    private javax.swing.JLabel lblselecMesa;
    private javax.swing.JLabel lblselecMesero;
    private javax.swing.JLabel lblselecProducto;
    private javax.swing.JTable tabla;
    // End of variables declaration//GEN-END:variables

    private void cargaMesa() {
       for(Mesa item: listaM){
          comboMesa.addItem(item);
       }
    }
    //---------------------------------------------------------------------------
    private void cargaMeseros() {
       for(Mesero item: listameser){
          comboMesero.addItem(item);
       }
    }
    //---------------------------------------------------------------------------
    private void armarCabezeraTabla() {
        ArrayList<Object> filaCabecera=new ArrayList<>();
        filaCabecera.add("Nombre");
        filaCabecera.add("Precio");
        filaCabecera.add("Codigo");
        for(Object it: filaCabecera){
            modelo.addColumn(it);
        }
        tabla.setModel(modelo);
    }

    private void cargarDatosPedidos() {
for(Producto p: listaP){
          modelo.addRow(new Object[]{p.getNombre(),p.getPrecio(),p.getCodigo()});
       }
      
          
       }
    //----------------------------------------------------------------------------------------
    }
        
    
    
    
    
    

