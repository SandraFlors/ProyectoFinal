package resto.entidades;

public class Pedido {
    //ATRIBUTOS-----------------------------------------------------------------

    private int idPedido;
    private boolean estado;
    private Mesa mesa;
    private Mesero mesero;
    private Producto producto;
    //CONSTRUCTORES-------------------------------------------------------------

    public Pedido() {
    }

    public Pedido(int idPedido, boolean estado) {
        this.idPedido = idPedido;
        this.estado = estado;
    }

    public Pedido( boolean estado, Mesa mesa, Mesero mesero, Producto producto) {
       
        this.estado = estado;
        this.mesa = mesa;
        this.mesero = mesero;
        this.producto = producto;
    }

    public Mesa getMesa() {
        return mesa;
    }

    public void setMesa(Mesa mesa) {
        this.mesa = mesa;
    }

    public Mesero getMesero() {
        return mesero;
    }

    public void setMesero(Mesero mesero) {
        this.mesero = mesero;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }
    

    public Pedido(boolean estado) {
        this.estado = estado;
    }
    //GETTERS Y SETTERS---------------------------------------------------------

    public int getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }
    //TO STRING-----------------------------------------------------------------

    @Override
    public String toString() {
        return "Pedido{" + "idPedido=" + idPedido + ", estado=" + estado + '}';
    }

}
